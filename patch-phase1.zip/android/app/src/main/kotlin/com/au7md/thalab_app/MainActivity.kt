package com.au7md.thalab_app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadata
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.util.ArrayList
import java.util.HashMap

class MainActivity : FlutterActivity() {
    private var mediaRecorder: MediaRecorder? = null
    private var currentRecordPath: String? = null
    private var currentRecordTitle: String? = null
    private var isRecPaused: Boolean = false
    private var studioChannel: MethodChannel? = null
    private var mediaSession: MediaSession? = null

    private val actionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            runOnUiThread {
                when (intent?.action) {
                    "THALAB_REC_PAUSE_RESUME" -> {
                        if (isRecPaused) resumeRecordingInternal() else pauseRecordingInternal()
                        studioChannel?.invokeMethod("onRecNotificationAction", if (isRecPaused) "paused" else "resumed")
                    }
                    "THALAB_REC_STOP_SAVE" -> {
                        val saved = stopAndExportRecordingInternal()
                        studioChannel?.invokeMethod("onRecNotificationAction", "stopped:$saved")
                    }
                    "THALAB_REC_CANCEL" -> {
                        cancelRecordingInternal()
                        studioChannel?.invokeMethod("onRecNotificationAction", "cancelled")
                    }
                    "THALAB_MEDIA_PREV" -> studioChannel?.invokeMethod("onMediaAction", "prev")
                    "THALAB_MEDIA_PLAY_PAUSE" -> studioChannel?.invokeMethod("onMediaAction", "play_pause")
                    "THALAB_MEDIA_NEXT" -> studioChannel?.invokeMethod("onMediaAction", "next")
                }
            }
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        createNotificationChannels()
        initMediaSession()
        AdhanChannel.register(flutterEngine, this)

        val filter = IntentFilter().apply {
            addAction("THALAB_REC_PAUSE_RESUME")
            addAction("THALAB_REC_STOP_SAVE")
            addAction("THALAB_REC_CANCEL")
            addAction("THALAB_MEDIA_PREV")
            addAction("THALAB_MEDIA_PLAY_PAUSE")
            addAction("THALAB_MEDIA_NEXT")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(actionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(actionReceiver, filter)
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.au7md.thalab_app/system_volume")
            .setMethodCallHandler { call, result ->
                val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                when (call.method) {
                    "getVolume" -> {
                        val cur = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                        result.success(if (maxVol > 0) cur.toDouble() / maxVol.toDouble() else 0.5)
                    }
                    "setVolume" -> {
                        val vol = (call.argument<Double>("volume") ?: 0.5).coerceIn(0.0, 1.0)
                        val target = (vol * maxVol).toInt().coerceIn(0, maxVol)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }

        val channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.au7md.thalab_app/audio_studio")
        studioChannel = channel
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "updateMediaNotification" -> {
                    val title = call.argument<String>("title") ?: "ملف صوتي"
                    val subtitle = call.argument<String>("subtitle") ?: "الثعلب"
                    val isPlaying = call.argument<Boolean>("isPlaying") ?: false
                    val durationMs = (call.argument<Int>("durationMs") ?: 0).toLong()
                    val positionMs = (call.argument<Int>("positionMs") ?: 0).toLong()
                    showMediaNotification(title, subtitle, isPlaying, durationMs, positionMs)
                    result.success(true)
                }
                "hideMediaNotification" -> {
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.cancel(9092)
                    mediaSession?.isActive = false
                    result.success(true)
                }
                "openExternalUrl" -> {
                    val url = call.argument<String>("url") ?: ""
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                        result.success(true)
                    } catch (_: Exception) {
                        result.success(false)
                    }
                }
                "getDeviceAudios" -> {
                    val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Manifest.permission.READ_MEDIA_AUDIO
                    } else {
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                    if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this, arrayOf(perm), 402)
                        result.success(ArrayList<Any>())
                        return@setMethodCallHandler
                    }
                    val list = ArrayList<HashMap<String, Any>>()
                    val projection = arrayOf(
                        MediaStore.Audio.Media._ID,
                        MediaStore.Audio.Media.TITLE,
                        MediaStore.Audio.Media.ARTIST,
                        MediaStore.Audio.Media.DATA,
                        MediaStore.Audio.Media.DURATION,
                        MediaStore.Audio.Media.DATE_ADDED
                    )
                    val cursor = contentResolver.query(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        projection,
                        "${MediaStore.Audio.Media.IS_MUSIC} != 0 OR ${MediaStore.Audio.Media.DURATION} > 1000",
                        null,
                        "${MediaStore.Audio.Media.DATE_ADDED} DESC"
                    )
                    cursor?.use { c ->
                        val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                        val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                        val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                        val dataCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                        val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                        val dateCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                        while (c.moveToNext()) {
                            val path = c.getString(dataCol) ?: continue
                            val fileObj = File(path)
                            if (!fileObj.exists()) continue
                            val title = c.getString(titleCol) ?: fileObj.nameWithoutExtension
                            val artist = c.getString(artistCol) ?: "مكتبة الجهاز"
                            val durMs = c.getLong(durCol)
                            val folderName = fileObj.parentFile?.name ?: "ملفات صوتية"
                            val item = HashMap<String, Any>()
                            item["id"] = c.getLong(idCol).toString()
                            item["title"] = title
                            item["artist"] = if (artist == "<unknown>") folderName else artist
                            item["folder"] = folderName
                            item["path"] = path
                            item["durationSec"] = (durMs / 1000L).toInt()
                            item["dateAdded"] = c.getLong(dateCol)
                            list.add(item)
                        }
                    }
                    result.success(list)
                }
                "hasRecordPermission" -> {
                    val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    val recGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (!recGranted) {
                        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 401)
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 403)
                    }
                    result.success(recGranted)
                }
                "startRecord" -> {
                    val path = call.argument<String>("path") ?: ""
                    val title = call.argument<String>("title") ?: "تسجيل الثعلب"
                    try {
                        mediaRecorder?.release()
                        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            MediaRecorder(this)
                        } else {
                            @Suppress("DEPRECATION")
                            MediaRecorder()
                        }
                        recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
                        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                        recorder.setAudioEncodingBitRate(128000)
                        recorder.setAudioSamplingRate(44100)
                        recorder.setOutputFile(path)
                        recorder.prepare()
                        recorder.start()
                        mediaRecorder = recorder
                        currentRecordPath = path
                        currentRecordTitle = title
                        isRecPaused = false
                        showRecordingNotification(title, false)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("REC_ERR", e.message, null)
                    }
                }
                "getAmplitude" -> {
                    try {
                        val amp = mediaRecorder?.maxAmplitude ?: 0
                        result.success((amp / 32767.0).coerceIn(0.08, 1.0))
                    } catch (_: Exception) {
                        result.success(0.15)
                    }
                }
                "pauseRecord" -> {
                    pauseRecordingInternal()
                    result.success(true)
                }
                "resumeRecord" -> {
                    resumeRecordingInternal()
                    result.success(true)
                }
                "stopRecord" -> {
                    val saved = stopAndExportRecordingInternal()
                    result.success(saved)
                }
                "cancelRecord" -> {
                    cancelRecordingInternal()
                    result.success(true)
                }
                "exportToMusicFolder" -> {
                    val srcPath = call.argument<String>("srcPath") ?: ""
                    val title = call.argument<String>("title") ?: "Thalab_Audio"
                    val subFolder = call.argument<String>("subFolder") ?: "Thalab Recordings"
                    val exportedPath = saveAudioToPublicMusic(srcPath, title, subFolder)
                    result.success(exportedPath)
                }
                "processAudioEdit" -> {
                    val srcPath = call.argument<String>("srcPath") ?: ""
                    val dstPath = call.argument<String>("dstPath") ?: ""
                    val mode = call.argument<String>("mode") ?: "keep"
                    val startMs = (call.argument<Int>("startMs") ?: 0).toLong()
                    val endMs = (call.argument<Int>("endMs") ?: 0).toLong()
                    try {
                        editAudioTrack(srcPath, dstPath, mode, startMs * 1000L, endMs * 1000L)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("EDIT_ERR", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun initMediaSession() {
        mediaSession = MediaSession(this, "ThalabMediaSession").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { runOnUiThread { studioChannel?.invokeMethod("onMediaAction", "play_pause") } }
                override fun onPause() { runOnUiThread { studioChannel?.invokeMethod("onMediaAction", "play_pause") } }
                override fun onSkipToNext() { runOnUiThread { studioChannel?.invokeMethod("onMediaAction", "next") } }
                override fun onSkipToPrevious() { runOnUiThread { studioChannel?.invokeMethod("onMediaAction", "prev") } }
            })
            isActive = false
        }
    }

    private fun showMediaNotification(
        title: String,
        subtitle: String,
        isPlaying: Boolean,
        durationMs: Long,
        positionMs: Long
    ) {
        val session = mediaSession ?: return
        session.isActive = true
        session.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, subtitle)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, durationMs)
                .build()
        )
        session.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or
                    PlaybackState.ACTION_PAUSE or
                    PlaybackState.ACTION_PLAY_PAUSE or
                    PlaybackState.ACTION_SKIP_TO_NEXT or
                    PlaybackState.ACTION_SKIP_TO_PREVIOUS
                )
                .setState(
                    if (isPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    positionMs,
                    if (isPlaying) 1.0f else 0.0f
                )
                .build()
        )

        val openPending = PendingIntent.getActivity(
            this, 20, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val prevPending = PendingIntent.getBroadcast(
            this, 21, Intent("THALAB_MEDIA_PREV").setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val playPausePending = PendingIntent.getBroadcast(
            this, 22, Intent("THALAB_MEDIA_PLAY_PAUSE").setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val nextPending = PendingIntent.getBroadcast(
            this, 23, Intent("THALAB_MEDIA_NEXT").setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "thalab_media_channel")
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        builder.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setContentIntent(openPending)
            .setOngoing(isPlaying)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "السابق", prevPending).build())
            .addAction(Notification.Action.Builder(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (isPlaying) "إيقاف" else "تشغيل", playPausePending).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "التالي", nextPending).build())
            .setStyle(Notification.MediaStyle()
                .setMediaSession(session.sessionToken)
                .setShowActionsInCompactView(0, 1, 2))

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(9092, builder.build())
    }

    private fun pauseRecordingInternal() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                mediaRecorder?.pause()
                isRecPaused = true
                showRecordingNotification(currentRecordTitle ?: "تسجيل الثعلب", true)
            }
        } catch (_: Exception) {}
    }

    private fun resumeRecordingInternal() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                mediaRecorder?.resume()
                isRecPaused = false
                showRecordingNotification(currentRecordTitle ?: "تسجيل الثعلب", false)
            }
        } catch (_: Exception) {}
    }

    private fun stopAndExportRecordingInternal(): String {
        try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        } catch (_: Exception) {}
        mediaRecorder = null
        isRecPaused = false
        dismissRecordingNotification()
        val src = currentRecordPath ?: return ""
        val title = currentRecordTitle ?: File(src).nameWithoutExtension
        val exported = saveAudioToPublicMusic(src, title, "Thalab Recordings")
        return exported.ifEmpty { src }
    }

    private fun cancelRecordingInternal() {
        try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        } catch (_: Exception) {}
        mediaRecorder = null
        isRecPaused = false
        dismissRecordingNotification()
        currentRecordPath?.let { File(it).delete() }
        currentRecordPath = null
    }

    private fun saveAudioToPublicMusic(srcPath: String, title: String, subFolder: String): String {
        val srcFile = File(srcPath)
        if (!srcFile.exists()) return ""
        val cleanName = if (title.endsWith(".m4a")) title else "$title.m4a"
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, cleanName)
                    put(MediaStore.Audio.Media.TITLE, title)
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/$subFolder")
                    put(MediaStore.Audio.Media.IS_MUSIC, 1)
                }
                val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(srcFile).use { input -> input.copyTo(out) }
                    }
                }
                "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)}/$subFolder/$cleanName"
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), subFolder)
                if (!dir.exists()) dir.mkdirs()
                val dst = File(dir, cleanName)
                srcFile.copyTo(dst, overwrite = true)
                dst.absolutePath
            }
        } catch (_: Exception) {
            srcPath
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("thalab_voice_rec_channel", "مسجل صوت الثعلب", NotificationManager.IMPORTANCE_HIGH)
            )
            nm.createNotificationChannel(
                NotificationChannel("thalab_media_channel", "مشغل صوتيات الثعلب", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun showRecordingNotification(title: String, paused: Boolean) {
        val openPending = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val pauseIntent = PendingIntent.getBroadcast(
            this, 11, Intent("THALAB_REC_PAUSE_RESUME").setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getBroadcast(
            this, 12, Intent("THALAB_REC_STOP_SAVE").setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cancelIntent = PendingIntent.getBroadcast(
            this, 13, Intent("THALAB_REC_CANCEL").setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, "thalab_voice_rec_channel")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (paused) "التسجيل متوقف مؤقتاً • الثعلب" else "جاري التسجيل الصوتي • الثعلب")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(0, if (paused) "استئناف" else "إيقاف مؤقت", pauseIntent)
            .addAction(0, "حفظ وإنهاء", stopIntent)
            .addAction(0, "إلغاء", cancelIntent)

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(9091, builder.build())
    }

    private fun dismissRecordingNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(9091)
    }

    private fun editAudioTrack(
        srcPath: String,
        dstPath: String,
        mode: String,
        startUs: Long,
        endUs: Long
    ) {
        val extractor = MediaExtractor()
        extractor.setDataSource(srcPath)
        var audioTrackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val fmt = extractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                format = fmt
                break
            }
        }
        if (audioTrackIndex < 0 || format == null) {
            extractor.release()
            throw IllegalStateException("No audio track")
        }
        extractor.selectTrack(audioTrackIndex)
        val muxer = MediaMuxer(dstPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val outTrack = muxer.addTrack(format)
        muxer.start()

        val buffer = ByteBuffer.allocate(256 * 1024)
        val info = MediaCodec.BufferInfo()
        val cutGapUs = (endUs - startUs).coerceAtLeast(0L)

        if (mode == "keep") {
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val sampleTime = extractor.sampleTime
                if (sampleTime > endUs) break
                if (sampleTime >= startUs) {
                    info.offset = 0
                    info.size = sampleSize
                    info.presentationTimeUs = sampleTime - startUs
                    info.flags = extractor.sampleFlags
                    muxer.writeSampleData(outTrack, buffer, info)
                }
                extractor.advance()
            }
        } else {
            extractor.seekTo(0L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val sampleTime = extractor.sampleTime
                if (sampleTime < startUs) {
                    info.offset = 0
                    info.size = sampleSize
                    info.presentationTimeUs = sampleTime
                    info.flags = extractor.sampleFlags
                    muxer.writeSampleData(outTrack, buffer, info)
                } else if (sampleTime > endUs) {
                    info.offset = 0
                    info.size = sampleSize
                    info.presentationTimeUs = (sampleTime - cutGapUs).coerceAtLeast(0L)
                    info.flags = extractor.sampleFlags
                    muxer.writeSampleData(outTrack, buffer, info)
                }
                extractor.advance()
            }
        }

        muxer.stop()
        muxer.release()
        extractor.release()
    }

    override fun onDestroy() {
        try { unregisterReceiver(actionReceiver) } catch (_: Exception) {}
        mediaSession?.release()
        super.onDestroy()
    }
}
